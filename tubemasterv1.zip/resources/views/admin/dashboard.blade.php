@extends('admin.layout')

@section('title', 'Dashboard')

@section('content')
<div class="page-content-wrapper py-3">
      <div class="container">
        <div class="card">
          <div class="card-body">
           <div class="row">
              <div class="col-md-4">
                <a href="{{route('clients.index')}}">Client</a>
              </div>

              <div class="col-md-4">
                <a href="{{route('equipments.index')}}">Equipment</a>
              </div>

              <div class="col-md-4">
                <a href="{{route('projects.index')}}">Project</a>
              </div>

           </div>
          </div>
        </div>
      </div>
    </div>
    @endsection