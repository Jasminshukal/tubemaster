

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content-wrapper py-3">
      <div class="container">
        <div class="card">
          <div class="card-body">
           <div class="row">
              <div class="col-md-4">
                <a href="<?php echo e(route('clients.index')); ?>">Client</a>
              </div>

              <div class="col-md-4">
                <a href="<?php echo e(route('equipments.index')); ?>">Equipment</a>
              </div>

              <div class="col-md-4">
                <a href="<?php echo e(route('projects.index')); ?>">Project</a>
              </div>

           </div>
          </div>
        </div>
      </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\pwa\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>